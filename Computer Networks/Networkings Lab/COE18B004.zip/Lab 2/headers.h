/*
created by Anant Patel
COE18B004
*/
#pragma once
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include<string.h>
#include <arpa/inet.h>

#define PORT 3000
#define BUFFER_SIZE 100
