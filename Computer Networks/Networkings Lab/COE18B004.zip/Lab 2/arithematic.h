/*
created by Anant Patel
COE18B004
*/
int sum(int num1, int num2);
int diff(int num1, int num2);
int pro(int num1, int num2);
float quo(int num1, int num2);
